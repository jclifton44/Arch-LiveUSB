tcpdump -vve | while read b; do
	echo "new line"
	echo $b
done
