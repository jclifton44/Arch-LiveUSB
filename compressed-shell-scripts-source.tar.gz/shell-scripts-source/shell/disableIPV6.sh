sysctl -p sysctl.conf
