echo "Before Link Up"
status
ip link set wlp2s0 up
echo "After Link Up"
status
