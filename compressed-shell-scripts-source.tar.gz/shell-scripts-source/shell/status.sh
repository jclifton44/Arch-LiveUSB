ip link
iw dev wlp2s0 link
