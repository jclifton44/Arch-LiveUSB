pacstrap /iomnt base base-devel dialog iw grub efibootmgr wpa_supplicant
