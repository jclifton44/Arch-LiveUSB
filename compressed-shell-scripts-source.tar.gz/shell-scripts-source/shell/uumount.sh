cd /
echo 'hihih


\n\\nhihihi\n\n\n'
